This is the backend for PurposeHouse application.

##SETUP

1. This is a python 3 app. So, ensure that you have python 3 installed.

2. GIT clone this application into your code editor of choice.

3. Open a new terminal (preferrably within your code editor) and ensure that it is navigated to the directory of this repo

4. Type 'python -m venv .venv' to create a new virtual environment.

5. Close and restart the terminal, ensuring that it's still navigated to the directory of this repo.

6. Install the required packages by typing 'pip install -r requirements.txt'

7. To start the application, type 'flask run'

8. You can then send requests to the application with the URL 'http://localhost:5000'. You can also view documentation for this (including available routes) by going to the browser and typing http://localhost:5000/api-docs
