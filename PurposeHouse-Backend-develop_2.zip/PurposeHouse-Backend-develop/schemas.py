from marshmallow import Schema, fields

class PlainClientSchema(Schema):
    id = fields.Int(dump_only=True)
    first_name = fields.Str(required=True)
    last_name = fields.Str(required=True)
    title = fields.Str(required=True)
    email = fields.Str(required=True)

class PlainAppointmentSchema(Schema):
    id = fields.Int(dump_only=True)
    date = fields.Str(required=True)
    description = fields.Str()
    note = fields.Str()
    feedback = fields.Str()

    client_id = fields.Int(required=True)
    councilor_id = fields.Int()

class PlainUserSchema(Schema):
    id = fields.Int(dump_only=True)
    first_name = fields.Str(required=True)
    last_name = fields.Str(required=True)
    title = fields.Str(required=True)
    role = fields.Str(dump_only=True)

    email = fields.Str(required=True)
    password = fields.Str(required=True, load_only=True)

class LoginSchema(Schema):
    access_token = fields.Str(dump_only=True)
    refresh_token = fields.Str(dump_only=True)

    email = fields.Str(load_only=True)
    password = fields.Str(load_only=True)

class RegisterSchema(LoginSchema):
    message = fields.Str(dump_only=True)

class RefreshSchema(Schema):
    access_token = fields.Str(dump_only=True)

class ClientSchema(PlainClientSchema):
    appointments = fields.List(fields.Nested(PlainAppointmentSchema(), dump_only=True))

class UserSchema(PlainUserSchema):
    appointments = fields.List(fields.Nested(PlainAppointmentSchema(), dump_only=True))

class AppointmentSchema(PlainAppointmentSchema):
    client = fields.Nested(PlainClientSchema(), dump_only=True)
    councilor = fields.Nested(PlainUserSchema(), dump_only=True)
