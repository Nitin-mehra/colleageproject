from db import db
from flask_smorest import abort

from models import UserModel

# Verifies if a user still exists in the database.
# Checks if a user's role is allowed.
def protect(requestor_id, allowed_roles):
    user = UserModel.query.get_or_404(requestor_id)

    if user.role not in allowed_roles:
        abort(401, message="Invalid permissions.")
