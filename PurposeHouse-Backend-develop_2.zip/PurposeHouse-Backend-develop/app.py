import os

from flask import Flask, request, session, redirect, render_template,g,url_for
from flask_smorest import Api
from db import db

from flask_jwt_extended import JWTManager

from resources.user import blp as UserBlueprint
from resources.client import blp as ClientBlueprint
from resources.appointment import blp as AppointmentBlueprint
from flask_sqlalchemy import SQLAlchemy
from models import UserModel

app = Flask(__name__)
app.debug = True

app.config["PROPAGATE_EXCEPTIONS"] = True
app.config["API_TITLE"] = "Stores REST API"
app.config["API_VERSION"] = "v1"
app.config["OPENAPI_VERSION"] = "3.0.3"
app.config["OPENAPI_URL_PREFIX"] = "/"
app.config["OPENAPI_SWAGGER_UI_PATH"] = "/api-docs"
app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"

# Connect to the database
app.config["SQLALCHEMY_DATABASE_URI"] =  os.getenv("DATABASE_URL", "sqlite:///data.db")
app.config["SQLALCHEMY_TRACK_MODIFICATION"] = False
db.init_app(app)

api = Api(app)

app.config["JWT_SECRET_KEY"] = "174256156345412616362974167403801169277"
jwt = JWTManager(app)

@app.before_first_request
def create_tables():
    db.create_all()

api.register_blueprint(UserBlueprint)
api.register_blueprint(ClientBlueprint)
api.register_blueprint(AppointmentBlueprint)

# adding configuration for using a sqlite database
app.config["SQLALCHEMY_DATABASE_URI"] =  os.getenv("DATABASE_URL", "sqlite:///data.db")
app.config["SQLALCHEMY_TRACK_MODIFICATION"] = False

# Creating an SQLAlchemy instance
db = SQLAlchemy(app)

# function to add profiles
@app.route('/add', methods=["POST"])
def UserRegister():
	first_name = request.form.get("first_name")
	last_name = request.form.get("last_name")
	title = request.form.get("title")
    role = request.form.get("role")
    email = request.form.get("email")
    password = request.form.get("password")
	# create an object of the UserModel class of models
	# and store data as a row in our datatable
	if first_name != '' and last_name != '':
        user_data = UserModel(id=id, first_name=first_name, last_name=last_name, title=title, role=role, email=email, password=password)
		db.session.add(user_data)
		db.session.commit()
		return redirect(url_for('profile'))
	else:
		return redirect(url_for('login'))

# For profile page
@app.route('/profile')
def profile():
    if not g.user:
        return redirect(url_for('login'))

    return render_template('profile.html')


@app.route('/bookappointment')
def bookappointment():
    return render_template('appointment.html')

if __name__ == '__main__':
    app.run()

# def create_app(db_url=None):
#     app = Flask(__name__)

#     app.config["PROPAGATE_EXCEPTIONS"] = True
#     app.config["API_TITLE"] = "Stores REST API"
#     app.config["API_VERSION"] = "v1"
#     app.config["OPENAPI_VERSION"] = "3.0.3"
#     app.config["OPENAPI_URL_PREFIX"] = "/"
#     app.config["OPENAPI_SWAGGER_UI_PATH"] = "/api-docs"
#     app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"
#     # Connect to the database
#     app.config["SQLALCHEMY_DATABASE_URI"] = db_url or os.getenv("DATABASE_URL", "sqlite:///data.db")
#     app.config["SQLALCHEMY_TRACK_MODIFICATION"] = False
#     db.init_app(app)

#     api = Api(app)

#     app.config["JWT_SECRET_KEY"] = "174256156345412616362974167403801169277"
#     jwt = JWTManager(app)

#     @app.before_first_request
#     def create_tables():
#         db.create_all()

#     api.register_blueprint(UserBlueprint)
#     api.register_blueprint(ClientBlueprint)
#     api.register_blueprint(AppointmentBlueprint)

#     return app


# -------------- Working code start-----------------------------
# app = Flask(__name__)
# app.secret_key = 'somesecretkeythatonlyishouldknow'

# @app.before_request
# def before_request():
#     g.user = None

#     if 'user_id' in session:
#         user = [x for x in users if x.id == session['user_id']][0]
#         g.user = user

# class User:
#     def __init__(self, id, username, password):
#         self.id = id
#         self.username = username
#         self.password = password

#     def __repr__(self):
#         return f'<User: {self.username}>'

# users = []
# users.append(User(id=1, username='Anthony', password='password'))
# users.append(User(id=2, username='Becca', password='secret'))
# users.append(User(id=3, username='Carlos', password='somethingsimple'))

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         session.pop('user_id', None)

#         username = request.form['username']
#         password = request.form['password']
        
#         user = [x for x in users if x.username == username][0]
#         if user and user.password == password:
#             session['user_id'] = user.id
#             return redirect(url_for('profile'))

#         return redirect(url_for('login'))

#     return render_template('login.html')

# @app.route('/profile')
# def profile():
#     if not g.user:
#         return redirect(url_for('login'))

#     return render_template('profile.html')


# if __name__ == "__main__":
#   app.run()
# ------------------------------------ working code end-------------------