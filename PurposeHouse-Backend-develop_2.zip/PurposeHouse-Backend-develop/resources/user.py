from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from passlib.hash import pbkdf2_sha256
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt, get_jwt_identity, jwt_required
from permissions import protect

from db import db
from models import UserModel
from schemas import PlainUserSchema, UserSchema, RegisterSchema, LoginSchema, RefreshSchema

blp = Blueprint("Users", "users", description="Operations on users")

@blp.route("/register")
class RegisterCouncilor(MethodView):
    @blp.arguments(PlainUserSchema)
    @blp.response(201, RegisterSchema, description="councilor successfully registered.")
    @blp.alt_response(422, description="Required fields for registering councilor not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the councilor.")
    def post(self, councilor_data):
        #1) First, check if the councilor email is on the whitelist. 

        #2) Create the user model from the councilor and append the needed information.
        councilor = UserModel(
            first_name = councilor_data["first_name"],
            last_name = councilor_data["last_name"],
            title =  councilor_data["title"],
            role = "councilor",

            email = councilor_data["email"],
            password = pbkdf2_sha256.hash(councilor_data["password"])
        )

        #3) Try to save the user model to the database.
        try:
            db.session.add(councilor)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the councilor to the database.")

        #4) Get the councilor from the database so we can get their ID.
        councilor = UserModel.query.filter(UserModel.email == councilor_data["email"]).first()

        #4) Create a JWT for the councilor so they can access their routes.
        access_token = create_access_token(identity=councilor.id, fresh=True)
        refresh_token = create_refresh_token(identity=councilor.id)

        return {"message": "councilor created successfully.", "access_token": access_token, "refresh_token": refresh_token}, 201

@blp.route("/login")
class LoginUser(MethodView):
    @blp.arguments(LoginSchema)
    @blp.response(200, LoginSchema)
    def post(self, login_data):
        user = UserModel.query.filter(UserModel.email == login_data["email"]).first()

        if user and pbkdf2_sha256.verify(login_data["password"], user.password):
            access_token = create_access_token(identity=user.id, fresh=True)
            refresh_token = create_refresh_token(identity=user.id)
            return {"access_token": access_token, "refresh_token": refresh_token}

        abort(401, message="Invalid credentials.")

@blp.route("/refresh")
class TokenRefresh(MethodView):
    @jwt_required(refresh=True)
    @blp.response(200, RefreshSchema)
    def post(self):
        current_user = get_jwt_identity()
        new_token = create_access_token(identity=current_user, fresh=False)
        return {"access_token": new_token}

@blp.route("/admin")
class Admin(MethodView):
    # @jwt_required() # DISABLED FOR CHECKPOINT 2
    @blp.arguments(PlainUserSchema)
    @blp.response(201, description="Admin created successfully.")
    @blp.alt_response(422, description="Required fields for registering councilor not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the councilor.")
    def post (self, admin_data):
        # Verify that the person creating a new admin is an admin and that
        # they exist.
        # PROTECT IS DISABLED FOR CHECKPOINT 2
        # protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        # Create the admin user model.
        admin = UserModel(
            first_name = admin_data["first_name"],
            last_name = admin_data["last_name"],
            title =  admin_data["title"],
            role = "admin",

            email = admin_data["email"],
            password = pbkdf2_sha256.hash(admin_data["password"])
        )

        #3) Try to save the user model to the database.
        try:
            db.session.add(admin)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the admin to the database.")

        return { "message": "Admin created successfully."}, 201



