from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from flask_jwt_extended import jwt_required, get_jwt_identity
from permissions import protect

from db import db
from models import AppointmentModel, UserModel
from schemas import PlainAppointmentSchema, AppointmentSchema

import datetime

blp = Blueprint("Appointments", "appointments", description="Operations on apppointments")

@blp.route("/appointment")
class AppointmentList(MethodView):
    @jwt_required()
    @blp.response(200, AppointmentSchema(many=True))
    def get(self, **kwargs):
        # This route includes pagination, which means that you can specify
        # the page and number of clients.
        return db.paginate(AppointmentModel.query)

    @jwt_required(fresh=True)
    @blp.arguments(PlainAppointmentSchema, description="Creates an appointment.")
    @blp.response(201, description="Appointment successfully created.")
    @blp.alt_response(422, description="Required fields for creating appointment not included.")
    @blp.alt_response(500, description="Server error in saving the appointment.")
    def post(self, appointment_data):
        #1) Ensure that the appointment is being made by a 
        # councilor and that the councilor exists.
        protect(requestor_id=get_jwt_identity(), allowed_roles=["councilor"])

        # Set the councilor ID based on whether it was passed or not.
        if "councilor_id" in appointment_data:
            councilor_id = appointment_data["councilor_id"]
        else:
            councilor_id = get_jwt_identity()

        #2) Create the appointment model
        appointment = AppointmentModel (
            date = datetime.datetime.strptime(appointment_data["date"], '%Y-%m-%d'),
            description = appointment_data["description"],
            note = appointment_data["note"],
            feedback = appointment_data["feedback"],

            client_id = appointment_data["client_id"],
            councilor_id = councilor_id
        )

        #3) Try to save the appointment model to the database.
        try:
            db.session.add(appointment)
            db.session.commit()
        except SQLAlchemyError as e:
            print(e)
            abort(500, message="There was an error in saving the appointment to the database.")

        return { "message": "Appointment successfully created."}, 201