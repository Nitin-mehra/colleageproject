from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from flask_jwt_extended import jwt_required, get_jwt_identity
from permissions import protect

from db import db
from models import ClientModel
from schemas import PlainClientSchema

blp = Blueprint("Clients", "clients", description="Operations on clients")

@blp.route("/client")
class ClientList(MethodView):
    @jwt_required()
    @blp.response(200, PlainClientSchema(many=True))
    def get(self, **kwargs):
        # This route includes pagination, which means that you can specify
        # the page and number of clients. 
        return db.paginate(ClientModel.query)
    
    @jwt_required(fresh=True)
    @blp.arguments(PlainClientSchema, description="Creates a client. Requires a fresh token.")
    @blp.response(201, description="Client successfully created.")
    @blp.alt_response(422, description="Required fields for creating client not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the client.")
    def post(self, client_data):
        #1) Create the client model
        client = ClientModel(**client_data)

        #2) Try to save the client model to the database.
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the client to the database.")

        return { "message": "Client successfully created."}, 201

@blp.route("/client/<int:client_id>")
class Client(MethodView):
    @jwt_required()
    @blp.response(200, PlainClientSchema)
    @blp.alt_response(404, description="Client not found.")
    def get(self, client_id):
        client = ClientModel.query.get_or_404(client_id)
        return client

    # This route updates clients, but also will create a client
    # if one with that ID doesn't exist.
    @jwt_required(fresh=True)
    @blp.arguments(PlainClientSchema)
    @blp.response(200, PlainClientSchema, description="Client successfully updated.")
    @blp.alt_response(201, description="Client successfully created.")
    @blp.alt_response(422, description="Required fields for creating client not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the client.")
    def put(self, client_data, client_id):
        client = ClientModel.query.get(client_id)
        if client:
            client.first_name = client_data["first_name"]
            client.last_name = client_data["last_name"]
            client.title = client_data["title"]
            client.email = client_data["email"]
        else:
            client = ClientModel(id=client_id, **client_data)

        # Try to update / create the client.
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving or updating the client to the database.")

        return client

    # Deletes a client from the database.
    # Only admins can access this route.
    @jwt_required(fresh=True)
    @blp.response(200, description="Client deleted successfully.")
    @blp.alt_response(404, description="Client not found.")
    def delete(self, client_id):
        #1) Abort the request if the user does not exist and restrict to admin
        protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        #2) Get the client from the database.
        client = ClientModel.query.get_or_404(client_id)

        #3) Delete the client from the database.
        db.session.delete(client)
        db.session.commit()
        return {"message": "Client deleted."}, 200

        

