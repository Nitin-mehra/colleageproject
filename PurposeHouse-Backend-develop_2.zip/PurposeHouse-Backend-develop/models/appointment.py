from db import db

class AppointmentModel(db.Model):
    __tablename__ = 'appointment'

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    note = db.Column(db.Text, nullable=True)
    feedback = db.Column(db.Text, nullable=True)
    
    client_id = db.Column(db.Integer, db.ForeignKey("client.id", ondelete="SET NULL"), nullable=False)
    councilor_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="SET NULL"), nullable=False)

    client = db.relationship("ClientModel", back_populates="appointments")
    councilor = db.relationship("UserModel", back_populates="appointments")